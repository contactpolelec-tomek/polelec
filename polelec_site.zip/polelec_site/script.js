// small helper script
document.getElementById('year') && (document.getElementById('year').textContent = new Date().getFullYear());